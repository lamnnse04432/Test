package com.example.starter;

import java.util.UUID;

public class StringUtils {
  public static String uniqueMessageId() {
    UUID uuid = UUID.randomUUID();
    return uuid.getLeastSignificantBits() + uuid.getLeastSignificantBits() + "";
  }
}
