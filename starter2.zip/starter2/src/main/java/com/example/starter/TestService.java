package com.example.starter;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.Promise;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.RoutingContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestService extends com.vps.bgw.rest.handler.AbstractHandler {

  private static final Logger LOG = LoggerFactory.getLogger(TestService.class);
  private static TestService instance;
  private final ObjectMapper objectMapper = new ObjectMapper();

  private final Vertx vertx;

  public TestService(Vertx vertx) {
    super(vertx);
    this.vertx = vertx;
  }


  private static <T> Future<T> withTimeout(Vertx vertx, long timeout, Handler<Promise<T>> operation) {
    Promise<T> promise = Promise.promise();

    long timerId = vertx.setTimer(timeout, id -> {
      if (!promise.future().isComplete()) {
        LOG.info("Timeout exceeded");
        promise.fail("Timeout exceeded");
      }
    });

    operation.handle(promise);

    promise.future().onComplete(ar ->{
      LOG.info("cancel timer : {}", timerId);
      vertx.cancelTimer(timerId);
    });

    return promise.future();
  }


  @Override
  protected void handleRequest(RoutingContext routingContext) {

    withTimeout(vertx, 10000, promise -> {
      vertx.setTimer(5000, id -> {
        LOG.info("operation completed");
        if (!promise.future().isComplete()) {
        LOG.info("chay vao day");
          promise.complete("operation completed");
        }

      });
    }).onComplete(result -> {
      if (result.succeeded()) {

        LOG.info("oke");
        this.sendResponse(routingContext,  "oke");
      } else {
        LOG.info(" timeout");
        this.sendResponse(routingContext, "timeout");
      }
    });

  }

  @Override
  protected String getApiName() {
    return null;
  }

  public synchronized Future<TokenInfoResp> handle(String id, Promise<TokenInfoResp>... promises) {
    Promise<TokenInfoResp> promise = promises.length > 0 ? promises[0] : Promise.promise();


    return promise.future();
  }
}
