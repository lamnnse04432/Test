package com.example.starter;


import io.vertx.core.Vertx;

import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.RoutingContext;
import org.jose4j.base64url.Base64Url;
import org.jose4j.jca.ProviderContext;
import org.jose4j.jwa.AlgorithmFactory;
import org.jose4j.jwa.AlgorithmFactoryFactory;
import org.jose4j.jwe.*;
import org.jose4j.jwx.CompactSerializer;
import org.jose4j.jwx.Headers;
import org.jose4j.keys.AesKey;
import org.jose4j.keys.HmacKey;
import org.jose4j.lang.ByteUtil;
import org.jose4j.lang.InvalidAlgorithmException;
import org.jose4j.lang.JoseException;
import org.jose4j.lang.StringUtil;
import org.jose4j.mac.MacUtil;
import org.jose4j.zip.CompressionAlgorithm;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.*;


public class AddWithdrawalsService extends com.vps.bgw.rest.handler.AbstractHandler {

  private Base64Url base64url = new Base64Url();

  protected Headers headers = new Headers();

  public AddWithdrawalsService(Vertx vertx) {
    super(vertx);
  }

  @Override
  protected void handleRequest(RoutingContext routingContext) {

    String uniqueId = StringUtils.uniqueMessageId();


    try {

      KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
      keyGen.initialize(2048);
      KeyPair keyPair = keyGen.generateKeyPair();
      PrivateKey privateKey = keyPair.getPrivate();
      PublicKey publicKey = keyPair.getPublic();
    String content = "Nguyen Ngoc Lam";
 String a =    this.encrypt(content,publicKey);
   String b =    this.getCompactSerialization(content,publicKey);

      LOG.info("{} | {} | Received a CBG request a: {}", uniqueId, getApiName(), a);
      LOG.info("{} | {} | Received a CBG request b: {}", uniqueId, getApiName(), b);



      this.sendResponse(routingContext, JsonObject.mapFrom(a), uniqueId);




    } catch (Exception e) {
      LOG.error("{} | " + e.getMessage(), uniqueId, e);

      this.sendResponse(routingContext,JsonObject.mapFrom(null), uniqueId);
    }
  }



  @Override
  protected String getApiName() {
    return "ADD-WITHDRAWLS";
  }

  public String decryptData(String content,PrivateKey privateKey) {
    String result = "";
    try {

      JsonWebEncryption jwe = new JsonWebEncryption();
      // jwe.setPayload(content);
      jwe.setAlgorithmHeaderValue(KeyManagementAlgorithmIdentifiers.RSA1_5);
      jwe.setEncryptionMethodHeaderParameter(ContentEncryptionAlgorithmIdentifiers.AES_128_CBC_HMAC_SHA_256);
      jwe.setKey(privateKey);
      jwe.setCompactSerialization(content);
      result = jwe.getPayload();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return result;
  }

  public String encrypt(String content,  PublicKey publicKey) {
    String result = "";
    try {
      JsonWebEncryption jwe = new JsonWebEncryption();
      jwe.setPayload(content);
      jwe.setAlgorithmHeaderValue(KeyManagementAlgorithmIdentifiers.RSA1_5);
      jwe.setEncryptionMethodHeaderParameter(ContentEncryptionAlgorithmIdentifiers.AES_128_CBC_HMAC_SHA_256);
      jwe.setKey(publicKey);
      result = jwe.getCompactSerialization();
    } catch (JoseException e) {
      e.printStackTrace();
    }
    return result;
  }

  private String plaintextCharEncoding = "UTF-8";
  public byte[] setPlaintext(String plaintext) {
    return StringUtil.getBytesUnchecked(plaintext, this.plaintextCharEncoding);
  }

  public String getCompactSerialization(String content,  PublicKey publicKey) throws JoseException {
    this.headers.setObjectHeaderValue("alg","RSA1_5");
    this.headers.setObjectHeaderValue("enc","A128CBC-HS256");

    KeyManagementAlgorithm keyManagementModeAlg = this.getKeyManagementModeAlgorithm();
    ContentEncryptionAlgorithm contentEncryptionAlg = this.getContentEncryptionAlgorithm();
    ContentEncryptionKeyDescriptor contentEncryptionKeyDesc = contentEncryptionAlg.getContentEncryptionKeyDescriptor();
    Key managementKey = publicKey;


    ContentEncryptionKeys contentEncryptionKeys = this.manageForEncrypt(managementKey, contentEncryptionKeyDesc);
 //  this.setContentEncryptionKey(contentEncryptionKeys.getContentEncryptionKey());
 //   this.encryptedKey = contentEncryptionKeys.getEncryptedKey();
    byte[] aad = this.getEncodedHeaderAsciiBytesForAdditionalAuthenticatedData();
    byte[] contentEncryptionKey = contentEncryptionKeys.getContentEncryptionKey();
    byte[] plaintextBytes = setPlaintext(content);
    if (plaintextBytes == null) {
      throw new NullPointerException("The plaintext payload for the JWE has not been set.");
    } else {
      plaintextBytes = this.compress(this.headers, plaintextBytes);
      this.checkCek(contentEncryptionAlg, contentEncryptionKeyDesc, contentEncryptionKey);
      ContentEncryptionParts contentEncryptionParts = this.encrypt(plaintextBytes, aad, contentEncryptionKey, this.headers, null);
    //  this.setIv(contentEncryptionParts.getIv());
    //  this.ciphertext = contentEncryptionParts.getCiphertext();
      String encodedIv = this.base64url.base64UrlEncode(contentEncryptionParts.getIv());
      String encodedCiphertext = this.base64url.base64UrlEncode(contentEncryptionParts.getCiphertext());
      String encodedTag = this.base64url.base64UrlEncode(contentEncryptionParts.getAuthenticationTag());
      byte[] encryptedKey = contentEncryptionKeys.getEncryptedKey();
      String encodedEncryptedKey = this.base64url.base64UrlEncode(encryptedKey);
      return CompactSerializer.serialize(new String[]{this.headers.getEncodedHeader(), encodedEncryptedKey, encodedIv, encodedCiphertext, encodedTag});
    }
  }

  public ContentEncryptionParts encrypt(byte[] plaintext, byte[] aad, byte[] contentEncryptionKey, Headers headers, byte[] ivOverride) throws JoseException {
    ProviderContext providerContext = new ProviderContext();
    byte[] iv = this.iv(16, ivOverride, providerContext.getSecureRandom());
    return this.encrypt(plaintext, aad, contentEncryptionKey, iv, headers, providerContext);
  }

  static byte[] iv(int byteLength, byte[] ivOverride, SecureRandom secureRandom) {
    return ivOverride == null ? ByteUtil.randomBytes(byteLength, secureRandom) : ivOverride;
  }
  ContentEncryptionParts encrypt(byte[] plaintext, byte[] aad, byte[] key, byte[] iv, Headers headers, ProviderContext providerContext) throws JoseException {
    Key hmacKey = new HmacKey(ByteUtil.leftHalf(key));
    Key encryptionKey = new AesKey(ByteUtil.rightHalf(key));
    String cipherProvider = this.getCipherProvider(headers, providerContext);
    Cipher cipher = this.getCipher("AES/CBC/PKCS5Padding", cipherProvider);

    try {
      cipher.init(1, encryptionKey, new IvParameterSpec(iv));
    } catch (InvalidKeyException var18) {
      throw new JoseException("Invalid key for " , var18);
    } catch (InvalidAlgorithmParameterException var19) {
      throw new JoseException(var19.toString(), var19);
    }

    byte[] cipherText;
    try {
      cipherText = cipher.doFinal(plaintext);
    } catch (BadPaddingException | IllegalBlockSizeException var17) {
      throw new JoseException(var17.toString(), var17);
    }

    String macProvider = this.getMacProvider(headers, providerContext);
    Mac mac = MacUtil.getInitializedMac("HmacSHA256", hmacKey, macProvider);
    byte[] al = this.getAdditionalAuthenticatedDataLengthBytes(aad);
    byte[] authenticationTagInput = ByteUtil.concat(new byte[][]{aad, iv, cipherText, al});
    byte[] authenticationTag = mac.doFinal(authenticationTagInput);
    authenticationTag = ByteUtil.subArray(authenticationTag, 0, 16);
    return new ContentEncryptionParts(iv, cipherText, authenticationTag);
  }

  private byte[] getAdditionalAuthenticatedDataLengthBytes(byte[] additionalAuthenticatedData) {
    long aadLength = (long)ByteUtil.bitLength(additionalAuthenticatedData);
    return ByteUtil.getBytes(aadLength);
  }

  private void checkCek(ContentEncryptionAlgorithm contentEncryptionAlg, ContentEncryptionKeyDescriptor contentEncryptionKeyDesc, byte[] rawCek) throws org.jose4j.lang.InvalidKeyException {
    int contentEncryptionKeyByteLength = contentEncryptionKeyDesc.getContentEncryptionKeyByteLength();
    if (rawCek.length != contentEncryptionKeyByteLength) {
      throw new org.jose4j.lang.InvalidKeyException(ByteUtil.bitLength(rawCek) + " bit content encryption key is not the correct size for the " + contentEncryptionAlg.getAlgorithmIdentifier() + " content encryption algorithm (" + ByteUtil.bitLength(contentEncryptionKeyByteLength) + ").");
    }
  }


  static String getCipherProvider(Headers headers, ProviderContext providerCtx) {
    ProviderContext.Context ctx = choseContext(headers, providerCtx);
    return ctx.getCipherProvider();
  }

  static String getMacProvider(Headers headers, ProviderContext providerContext) {
    ProviderContext.Context ctx = choseContext(headers, providerContext);
    return ctx.getMacProvider();
  }


  private static ProviderContext.Context choseContext(Headers headers, ProviderContext providerCtx) {
    boolean isDir = headers != null && "dir".equals(headers.getStringHeaderValue("alg"));
    return isDir ? providerCtx.getSuppliedKeyProviderContext() : providerCtx.getGeneralProviderContext();
  }


  byte[] compress(Headers headers, byte[] data) throws InvalidAlgorithmException {
    String zipHeaderValue = headers.getStringHeaderValue("zip");
    if (zipHeaderValue != null) {
      AlgorithmFactoryFactory factoryFactory = AlgorithmFactoryFactory.getInstance();
      AlgorithmFactory<CompressionAlgorithm> zipAlgFactory = factoryFactory.getCompressionAlgorithmFactory();
      CompressionAlgorithm compressionAlgorithm = (CompressionAlgorithm)zipAlgFactory.getAlgorithm(zipHeaderValue);
      data = compressionAlgorithm.compress(data);
    }

    return data;
  }

  public ContentEncryptionKeys manageForEncrypt(Key managementKey, ContentEncryptionKeyDescriptor cekDesc) throws JoseException {
    byte[] contentEncryptionKey =ByteUtil.randomBytes(cekDesc.getContentEncryptionKeyByteLength()) ;
    return this.manageForEnc(managementKey, cekDesc, contentEncryptionKey);
  }

  protected ContentEncryptionKeys manageForEnc(Key managementKey, ContentEncryptionKeyDescriptor cekDesc, byte[] contentEncryptionKey ) throws JoseException {
    ProviderContext providerContext=  new ProviderContext();
    ProviderContext.Context ctx = providerContext.getSuppliedKeyProviderContext();
    String provider = ctx.getCipherProvider();
    Cipher cipher = this.getCipher("RSA/ECB/PKCS1Padding", provider);
    try {

 cipher.init(3, managementKey);
      String contentEncryptionKeyAlgorithm = cekDesc.getContentEncryptionKeyAlgorithm();
      byte[] encryptedKey = cipher.wrap(new SecretKeySpec(contentEncryptionKey, contentEncryptionKeyAlgorithm));
      return new ContentEncryptionKeys(contentEncryptionKey, encryptedKey);
    } catch (InvalidKeyException var10) {
      throw new org.jose4j.lang.InvalidKeyException("Unable to encrypt (" + cipher.getAlgorithm() + ") the Content Encryption Key: " + var10, var10);
    } catch (IllegalBlockSizeException var11) {
      throw new JoseException("Unable to encrypt (" + cipher.getAlgorithm() + ") the Content Encryption Key: " + var11, var11);
    }
  }

  static Cipher getCipher(String algorithm, String provider) throws JoseException {
    try {
      return provider == null ? Cipher.getInstance(algorithm) : Cipher.getInstance(algorithm, provider);
    } catch (NoSuchPaddingException | NoSuchAlgorithmException var3) {
      throw new JoseException(var3.toString(), var3);
    } catch (NoSuchProviderException var4) {
      throw new JoseException("Unable to get a Cipher implementation of " + algorithm + " using provider " + provider, var4);
    }
  }

  KeyManagementAlgorithm getKeyManagementModeAlgorithm() throws InvalidAlgorithmException {
    String algo = "RSA1_5";

      AlgorithmFactoryFactory factoryFactory = AlgorithmFactoryFactory.getInstance();
      AlgorithmFactory<KeyManagementAlgorithm> factory = factoryFactory.getJweKeyManagementAlgorithmFactory();
      return factory.getAlgorithm(algo);
    }

  public ContentEncryptionAlgorithm getContentEncryptionAlgorithm() throws InvalidAlgorithmException {
    String encValue = "A128CBC-HS256";

      AlgorithmFactoryFactory factoryFactory = AlgorithmFactoryFactory.getInstance();
      AlgorithmFactory<ContentEncryptionAlgorithm> factory = factoryFactory.getJweContentEncryptionAlgorithmFactory();
      return factory.getAlgorithm(encValue);

  }

  byte[] getEncodedHeaderAsciiBytesForAdditionalAuthenticatedData() {
    String encodedHeader = this.headers.getEncodedHeader();
    return StringUtil.getBytesAscii(encodedHeader);
  }

  public void setStringHeaderValue(String name, String value) {
    this.headers.setObjectHeaderValue(name,value);
  }


}
