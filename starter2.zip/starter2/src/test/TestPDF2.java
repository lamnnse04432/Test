import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.StampingProperties;
import com.itextpdf.signatures.*;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.asn1.x509.KeyUsage;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import java.io.*;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Collection;
import java.util.Date;
import com.spire.pdf.PdfDocument;
import com.spire.pdf.graphics.PdfFont;
import com.spire.pdf.graphics.PdfFontFamily;
import com.spire.pdf.graphics.PdfFontStyle;
import com.spire.pdf.graphics.PdfImage;
import com.spire.pdf.security.GraphicMode;
import com.spire.pdf.security.PdfCertificate;
import com.spire.pdf.security.PdfCertificationFlags;
import com.spire.pdf.security.PdfSignature;

import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
public class TestPDF2 {

  public static void main(String[] args) {

    //Load a pdf document
    PdfDocument doc = new PdfDocument();
    doc.loadFromFile("C:\\Users\\Administrator\\Desktop\\Moon.pdf");

    //Load the certificate
    PdfCertificate cert = new PdfCertificate("F:\\pfx\\output\\Test.pfx", "111");

    //Create a PdfSignature object and specify its position and size
    PdfSignature signature = new PdfSignature(doc, doc.getPages().get(0), cert, "MySignature");
    Rectangle2D rect = new Rectangle2D.Float();
    rect.setFrame(new Point2D.Float((float) doc.getPages().get(0).getActualSize().getWidth() - 380, (float) doc.getPages().get(0).getActualSize().getHeight() - 120), new Dimension(250, 150));
    signature.setBounds(rect);

    //Set the graphics mode
    signature.setGraphicMode(GraphicMode.Sign_Image_And_Sign_Detail);

    //Set the signature content
    signature.setNameLabel("Signer:");
    signature.setName("Jessie");
    signature.setContactInfoLabel("ContactInfo:");
    signature.setContactInfo("xxxxxxxxx");
    signature.setDateLabel("Date:");
    signature.setDate(new java.util.Date());
    signature.setLocationInfoLabel("Location:");
    signature.setLocationInfo("Florida");
    signature.setReasonLabel("Reason: ");
    signature.setReason("The certificate of this document");
    signature.setDistinguishedNameLabel("DN: ");
    signature.setDistinguishedName(signature.getCertificate().get_IssuerName().getName());
    signature.setSignImageSource(PdfImage.fromFile("C:\\Users\\Administrator\\Desktop\\cert.jpg"));

    //Set the signature font
    signature.setSignDetailsFont(new PdfFont(PdfFontFamily.Helvetica, 10f, PdfFontStyle.Bold));

    //Set the document permission
    signature.setDocumentPermissions(PdfCertificationFlags.Forbid_Changes);
    signature.setCertificated(true);

    //Save to file
    doc.saveToFile("AddSignature.pdf");
    doc.close();
  }
}
