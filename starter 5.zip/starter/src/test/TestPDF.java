import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.StampingProperties;
import com.itextpdf.signatures.*;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.style.BCStyle;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.asn1.x509.KeyUsage;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import java.math.BigInteger;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.Date;

import java.util.Collection;



public class TestPDF {

  public static final String DEST = "./src/test/sign/example.pdf";

  public static final String SRC = "./src/test/example.pdf";

  public static final String KEYSTORE = "./src/test/ks";

  public static final char[] PASSWORD = "password".toCharArray();



  public final String[] RESULT_FILES = new String[]{
    "hello_signed1.pdf",
    "hello_signed2.pdf",
    "hello_signed3.pdf",
    "hello_signed4.pdf"
  };

  public static void main(String[] args) throws Exception {
   // PrivateKey pk = getPrivateKeyFrLocal("config/sit-vps-privatekey.pfx", "Vps_SSC@2023");
    //   PublicKey publicKey = getPublicKeyFrLocalString("config/sit-vps-publickey.pem");
  //  Certificate[] chain = readCertificateChain("config/sit-vps-publickey.pem");

//    KeyPair rootKeyPair = generateKeyPair();
//    X509Certificate rootCertificate = generateSelfSignedCertificate(rootKeyPair, "CN=Root Certificate");
//
//    KeyPair intermediateKeyPair = generateKeyPair();
//    X509Certificate intermediateCertificate = generateCertificate(intermediateKeyPair, rootKeyPair.getPrivate(), rootCertificate, "CN=Intermediate Certificate");
//
//    Certificate[] chain = new Certificate[]{intermediateCertificate, rootCertificate};
//
//
//    PrivateKey pk =rootKeyPair.getPrivate();


    BouncyCastleProvider provider = new BouncyCastleProvider();
    Security.addProvider(provider);
    KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
    ks.load(new FileInputStream(KEYSTORE), PASSWORD);
    String alias = ks.aliases().nextElement();
    PrivateKey pk = (PrivateKey) ks.getKey(alias, PASSWORD);
    Certificate[] chain = ks.getCertificateChain(alias);

    File file = new File(DEST);
    file.mkdirs();

//    BouncyCastleProvider provider = new BouncyCastleProvider();
//    Security.addProvider(provider);

    sign(SRC, DEST, chain, pk, DigestAlgorithms.SHA256, provider.getName(), PdfSigner.CryptoStandard.CMS, "Test 1", "Ghent");
  }

  public static void sign(String src, String dest, Certificate[] chain, PrivateKey pk, String digestAlgorithm,
                          String provider, PdfSigner.CryptoStandard signatureType, String reason, String location)
    throws GeneralSecurityException, IOException {
    PdfReader reader = new PdfReader(src);
    PdfSigner signer = new PdfSigner(reader, new FileOutputStream(dest), new StampingProperties());

// Create the signature appearance
     Rectangle rect = new Rectangle(36, 648, 200, 100);
    PdfSignatureAppearance appearance = signer.getSignatureAppearance();
    appearance
      .setReason(reason)
      .setLocation(location)

// Specify if the appearance before field is signed will be used
// as a background for the signed field. The "false" value is the default value.
      .setReuseAppearance(false)
      .setPageRect(rect)
      .setPageNumber(1);
    signer.setFieldName("sig");

    IExternalSignature pks = new PrivateKeySignature(pk, digestAlgorithm, provider);
    IExternalDigest digest = new BouncyCastleDigest();

// Sign the document using the detached mode, CMS or CAdES equivalent.
    signer.signDetached(digest, pks, chain, null, null, null, 0, signatureType);
  }

  public static PrivateKey getPrivateKeyFrLocal(String path, String password) throws Exception {
    KeyStore keystore = KeyStore.getInstance("PKCS12");


    InputStream fileInputStream = new FileInputStream(new File(path));
    keystore.load(fileInputStream, password.toCharArray());
    return (PrivateKey) keystore.getKey(keystore.aliases().nextElement(), password.toCharArray());
  }

  protected static PublicKey getPublicKeyFrLocalString(String path) {
    try {
      byte[] keyBytes = Files.readAllBytes(Paths.get(path));
      String publicKeyContent = new String(keyBytes);
      publicKeyContent = publicKeyContent.replace("\r", "").replace("\n", "").replace("-----BEGIN PUBLIC KEY-----", "").replace("-----END PUBLIC KEY-----", "");
      X509EncodedKeySpec encodedKeySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyContent));
      return KeyFactory.getInstance("RSA").generatePublic(encodedKeySpec);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  public static Certificate readCertificate(String filePath) throws Exception {
    try (InputStream inStream = new FileInputStream(filePath)) {
      CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
      return certFactory.generateCertificate(inStream);
    }
  }

  public static Certificate[] readCertificateChain(String filePath) throws Exception {
    try (InputStream inStream = new FileInputStream(filePath)) {
      CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
      Collection<? extends Certificate> certs = certFactory.generateCertificates(inStream);
      return certs.toArray(new Certificate[0]);
    }
  }


  static {
    Security.addProvider(new BouncyCastleProvider());
  }


  private static KeyPair generateKeyPair() throws NoSuchAlgorithmException {
    KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
    keyPairGenerator.initialize(2048);
    return keyPairGenerator.generateKeyPair();
  }
  private static X509Certificate generateSelfSignedCertificate(KeyPair keyPair, String dn) throws Exception {
    X500Name issuer = new X500Name(dn);
    BigInteger serialNumber = BigInteger.valueOf(System.currentTimeMillis());
    Date notBefore = new Date(System.currentTimeMillis() - 1000L * 60 * 60 * 24);
    Date notAfter = new Date(System.currentTimeMillis() + 1000L * 60 * 60 * 24 * 365);
    X500Name subject = issuer; // Self-signed, so issuer is the same as subject

    JcaX509v3CertificateBuilder certBuilder = new JcaX509v3CertificateBuilder(
      issuer, serialNumber, notBefore, notAfter, subject, keyPair.getPublic());

    KeyUsage keyUsage = new KeyUsage(KeyUsage.digitalSignature | KeyUsage.keyEncipherment);
    certBuilder.addExtension(Extension.keyUsage, true, keyUsage);

    ContentSigner contentSigner = new JcaContentSignerBuilder("SHA256WithRSAEncryption")
      .setProvider("BC").build(keyPair.getPrivate());

    X509CertificateHolder certHolder = certBuilder.build(contentSigner);
    return new JcaX509CertificateConverter().setProvider("BC").getCertificate(certHolder);
  }


  private static X509Certificate generateCertificate(KeyPair keyPair, PrivateKey caPrivateKey, X509Certificate caCertificate, String dn) throws Exception {
    X500Name issuer = new X500Name(caCertificate.getSubjectX500Principal().getName());
    BigInteger serialNumber = BigInteger.valueOf(System.currentTimeMillis());
    Date notBefore = new Date(System.currentTimeMillis() - 1000L * 60 * 60 * 24);
    Date notAfter = new Date(System.currentTimeMillis() + 1000L * 60 * 60 * 24 * 365);
    X500Name subject = new X500Name(dn);

    JcaX509v3CertificateBuilder certBuilder = new JcaX509v3CertificateBuilder(
      issuer, serialNumber, notBefore, notAfter, subject, keyPair.getPublic());

    KeyUsage keyUsage = new KeyUsage(KeyUsage.digitalSignature | KeyUsage.keyEncipherment);
    certBuilder.addExtension(Extension.keyUsage, true, keyUsage);

    ContentSigner contentSigner = new JcaContentSignerBuilder("SHA256WithRSAEncryption")
      .setProvider("BC").build(caPrivateKey);

    X509CertificateHolder certHolder = certBuilder.build(contentSigner);
    return new JcaX509CertificateConverter().setProvider("BC").getCertificate(certHolder);
  }


}
