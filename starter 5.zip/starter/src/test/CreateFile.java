import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfVersion;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;

import java.io.FileNotFoundException;


public class CreateFile {
  public static void main(String[] args) {
    String dest = "./src/test/sign/example.pdf"; // Path to the output PDF file

    try {
      // Initialize PDF writer

      // Initialize PDF document with version 1.6
      PdfWriter writer = new PdfWriter(dest, new com.itextpdf.kernel.pdf.WriterProperties().setPdfVersion(PdfVersion.PDF_1_6));
      PdfDocument pdfDoc = new PdfDocument(writer);
      // Initialize document
      Document document = new Document(pdfDoc);

      // Add a paragraph to the document
      document.add(new Paragraph("Hello, PDF 1.6!"));

      // Close the document
      document.close();

      System.out.println("PDF created successfully with version 1.6.");
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
  }
}
