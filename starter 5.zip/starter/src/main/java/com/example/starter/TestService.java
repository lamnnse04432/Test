package com.example.starter;


import io.vertx.core.Vertx;
import io.vertx.core.eventbus.EventBus;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.RoutingContext;
import org.jose4j.base64url.Base64Url;
import org.jose4j.jwx.Headers;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;


public class TestService extends com.vps.bgw.rest.handler.AbstractHandler {

  protected Headers headers = new Headers();
  private Base64Url base64url = new Base64Url();

  public TestService(Vertx vertx) {
    super(vertx);
  }

  @Override
  protected void handleRequest(RoutingContext routingContext) {

    String uniqueId = StringUtils.uniqueMessageId();


    try {
      EventBus eventBus = vertx.eventBus();
      eventBus.request("request.address", "Hello from RequestVerticle!", reply -> {
        if (reply.succeeded()) {
          System.out.println("Received reply: " + reply.result().body());
          this.sendResponse(routingContext, "ok", uniqueId);
        } else {
          System.out.println("Failed to receive reply: " + reply.cause());
          this.sendResponse(routingContext, "faile", uniqueId);
        }
      });





    } catch (Exception e) {
      LOG.error("{} | " + e.getMessage(), uniqueId, e);

      this.sendResponse(routingContext, "error", uniqueId);
    }
  }


  @Override
  protected String getApiName() {
    return "ADD-WITHDRAWLS";
  }


}
