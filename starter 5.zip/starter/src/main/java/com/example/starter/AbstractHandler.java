package com.vps.bgw.rest.handler;

import com.example.starter.GetTokenService;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.vertx.circuitbreaker.CircuitBreaker;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.eventbus.EventBus;
import io.vertx.core.http.HttpHeaders;
import io.vertx.core.http.HttpServerRequest;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.core.json.JsonObject;
import io.vertx.core.net.SocketAddress;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.client.WebClient;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public abstract class AbstractHandler implements Handler<RoutingContext> {

  protected static final Logger LOG = LoggerFactory.getLogger(AbstractHandler.class);

  protected ObjectMapper objectMapper = new ObjectMapper();
  protected final WebClient webClient;
  protected final Vertx vertx;

  protected final GetTokenService getToken;


  protected AbstractHandler(Vertx vertx) {
    this.vertx = vertx;
    this.webClient = com.vps.bgw.common.WebClientManager.getInstance().getWebClient(vertx, this.getApiName());
    this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    this.getToken = GetTokenService.getInstance(this.vertx);
  }

  @Override
  public void handle(RoutingContext routingContext) {
    handleRequest(routingContext);
  }

  protected abstract void handleRequest(RoutingContext routingContext);

  protected abstract String getApiName();


  protected void sendResponse(RoutingContext routingContext, JsonObject res, String uniqueId) {
    HttpServerResponse response = routingContext.response();
    response.putHeader(HttpHeaders.CONTENT_TYPE, "application/json");
    LOG.info("{} | {} | Send response to CBG: {}", uniqueId, getApiName(), res);
    response.end(res.toString());
  }

  protected void sendResponse(RoutingContext routingContext, String res, String uniqueId) {
    HttpServerResponse response = routingContext.response();
    response.putHeader(HttpHeaders.CONTENT_TYPE, "application/json");
    LOG.info("{} | {} | Send response to CBG: {}", uniqueId, getApiName(), res);
    response.end(res.toString());
  }


  protected void sendResponse(RoutingContext routingContext, String res) {
    HttpServerResponse response = routingContext.response();
    response.putHeader(HttpHeaders.CONTENT_TYPE, "application/json");
    LOG.info("{} | {} | Send response to CBG: {}", getApiName(), res);
    response.end(res.toString());
  }

}
