package com.example.starter;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.eventbus.EventBus;
import io.vertx.ext.web.client.WebClient;

public class TestVerticle extends AbstractVerticle {

  @Override
  public void start() {
    WebClient webClient = com.vps.bgw.common.WebClientManager.getInstance().getWebClient(vertx, "LOGIN");
    EventBus eventBus = vertx.eventBus();

    // Register a consumer to listen for messages
    eventBus.consumer("request.address", message -> {
      System.out.println("Received request: " + message.body());

      webClient.getAbs("http://127.0.0.1:8282/test")
        .timeout(60000)
        .putHeader("Content-Type", "application/json")
        .sendJsonObject(null)
        .onSuccess(response -> {
          try {
            message.reply("Hello from ResponseVerticle!");
          } catch (Exception e) {
            message.reply("Hello from ResponseVerticle!");

          }
        }).onFailure(throwable -> {
          message.reply("Hello from ResponseVerticle!");
        });

      // Send a reply

    });
  }
}

